package com.example.studentbio;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    DataBase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         db = new DataBase(MainActivity.this);

        if (db.findUser("Admin","1999") == false){
            db.insertUser("Admin","1999");
        }

        Toolbar tool = findViewById(R.id.toolMain);
        setSupportActionBar(tool);

        getSupportActionBar().setTitle("");


        Button btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    EditText etName = findViewById(R.id.editName);
                    EditText etPass = findViewById(R.id.editPassword);

                    DataBase db2 = new DataBase(MainActivity.this);

                    boolean find = db2.findUser(etName.getText().toString().replace(" ",""),etPass.getText().toString().replace(" ",""));

                    if(find == true){
                        etName.setText("");
                        etPass.setText("");
                        Intent intent = new Intent(MainActivity.this,MenuActivity.class);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Not Registered", Toast.LENGTH_SHORT).show();
                    }
                }catch (Exception ex){
                    Toast.makeText(MainActivity.this, ex.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}