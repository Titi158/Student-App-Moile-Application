package com.example.studentbio;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DataBase extends SQLiteOpenHelper {
    public DataBase(@Nullable Context context) {
        super(context, "studDb", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String stmt = "create table Students(Id integer primary key autoincrement,Name text(30),Course text(30),Year text(30),Dob text(30),Nation text(30),Image blob,StudentNo text(30))";
        db.execSQL(stmt);

        String stmt2 = "create table Users(Id integer primary key autoincrement,Name text(30),Password text(30))";
        db.execSQL(stmt2);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean insertStd(Student student){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Name",student.getName());
        cv.put("Course",student.getCourse());
        cv.put("Year",student.getYear());
        cv.put("Dob",student.getDob());
        cv.put("Nation",student.getNationality());
        cv.put("Image",student.getImg());
        cv.put("StudentNo",student.getStudNo());

        long insert = db.insert("Students", null, cv);
        if(insert == 1){
            return true;
        }
        else{
            return false;
        }
    }

    public List<Student> getAll(){
        SQLiteDatabase db = getReadableDatabase();
        String stmt = "select * from Students";

        List<Student> studList = new ArrayList<>();

        Cursor cursor = db.rawQuery(stmt, null);
        if(cursor.moveToFirst()){
            do{
                Student student = new Student();
                student.setName(cursor.getString(1));
                student.setYear(cursor.getString(3));
                student.setNationality(cursor.getString(5));
                student.setDob(cursor.getString(4));
                student.setCourse(cursor.getString(2));
                student.setImg(cursor.getBlob(6));
                student.setStudNo(cursor.getString(7));
                student.setId(cursor.getInt(0));

                studList.add(student);
            }while (cursor.moveToNext());
        }

        return studList;
    }

    public List<Student> getAll2(String name){
        SQLiteDatabase db = getReadableDatabase();
        String stmt = "select * from Students where Name like '%"+name+"%'";

        List<Student> studList = new ArrayList<>();

        Cursor cursor = db.rawQuery(stmt, null);
        if(cursor.moveToFirst()){
            do{
                Student student = new Student();
                student.setName(cursor.getString(1));
                student.setYear(cursor.getString(3));
                student.setNationality(cursor.getString(5));
                student.setDob(cursor.getString(4));
                student.setCourse(cursor.getString(2));
                student.setImg(cursor.getBlob(6));
                student.setStudNo(cursor.getString(7));
                student.setId(cursor.getInt(0));

                studList.add(student);
            }while (cursor.moveToNext());
        }

        return studList;
    }

    public boolean insertUser(String name,String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Name",name);
        cv.put("Password",password);

        long insert = db.insert("Users", null, cv);
        if(insert == 1){
            return true;
        }
        else{
            return false;
        }
    }

    public boolean findUser(String name,String password){
        SQLiteDatabase db = this.getReadableDatabase();
        String stmt = "select * from Users where Name = '"+name+"' and Password = '"+password+"' ";

        Cursor cursor = db.rawQuery(stmt, null);
        if(cursor.moveToFirst()){
            return true;
        }
        return false;
    }

    public boolean updateStd(Student student){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Name",student.getName());
        cv.put("Course",student.getCourse());
        cv.put("Year",student.getYear());
        cv.put("Dob",student.getDob());
        cv.put("Nation",student.getNationality());
        cv.put("Image",student.getImg());
        cv.put("StudentNo",student.getStudNo());

        String [] clause = {"" + student.getId()};

        long insert = db.update("Students", cv," Id = ?", clause );
        if(insert == 1){
            return true;
        }
        else{
            return false;
        }
    }

    public void deleteStudent(int Id){
        SQLiteDatabase db = getWritableDatabase();
        String stmt = "delete from Students where Id = "+Id+"";
          db.execSQL(stmt);

    }
}
