package com.example.studentbio;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Calendar;

public class Register extends AppCompatActivity {
    EditText etName,etCourse,etDob,etNo;
    Spinner spinnerYear,spinnerNation;

    String[] nations = {"Ugandan","Kenyan","Tanzanian","Rwandese","Burundian"};
    String[] years = {"Year 1","Year 2","Year 3","Year 4"};
    byte[] studImg;
    ImageView imgStudent,imgButton;
    final int REQUEST_IMAGE_CAPTURE = 2;
    int day,month,year;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK){
            Bundle bmp =  data.getExtras();
            Bitmap bmp2 = (Bitmap) bmp.get("data");
            imgStudent.setImageBitmap(bmp2);

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            bmp2.compress(Bitmap.CompressFormat.JPEG,100,out);

            studImg = out.toByteArray();


        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Student student0 = (Student) getIntent().getSerializableExtra("Student");



        DataBase db = new DataBase(Register.this);

        spinnerNation = findViewById(R.id.spinnerNation);
        spinnerYear = findViewById(R.id.spinnerYear);
        etCourse = findViewById(R.id.editCourse);
        etDob = findViewById(R.id.editDob);
        etName = findViewById(R.id.editName);
        etNo = findViewById(R.id.editNo);
        imgStudent = findViewById(R.id.imgStudent);
        imgButton = findViewById(R.id.btnCamera);

        Calendar calendar = Calendar.getInstance();
        day = calendar.get(Calendar.DAY_OF_MONTH);
        month = calendar.get(Calendar.MONTH);
        year = calendar.get(Calendar.YEAR);

        ArrayAdapter adapter1 = new ArrayAdapter(Register.this, android.R.layout.simple_spinner_dropdown_item,nations);
        ArrayAdapter adapter2 = new ArrayAdapter(Register.this, android.R.layout.simple_spinner_dropdown_item,years);

        spinnerYear.setAdapter(adapter2);
        spinnerNation.setAdapter(adapter1);

        Button btnReg = findViewById(R.id.btnReg);

        if(student0 != null){
            etDob.setText(student0.getDob());
            etName.setText(student0.getName());
            etCourse.setText(student0.getCourse());
            etNo.setText(student0.getStudNo());
            spinnerNation.setSelection(adapter1.getPosition(student0.getNationality()));
            spinnerYear.setSelection(adapter2.getPosition(student0.getYear()));

            if(student0.getImg() != null){
                Bitmap bmp = BitmapFactory.decodeByteArray(student0.getImg(),0,student0.getImg().length);
                imgStudent.setImageBitmap(bmp);
            }

            btnReg.setText("Update Student");
        }

        setDate(day,month,year);

        etDob.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                showDialog(190);
                return true;
            }
        });



        imgButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,REQUEST_IMAGE_CAPTURE);
            }
        });



        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              try{
                  Student student = new Student();
                  student.setCourse(etCourse.getText().toString());
                  student.setDob(etDob.getText().toString());
                  student.setImg(studImg);
                  student.setName(etName.getText().toString());
                  student.setNationality(spinnerNation.getSelectedItem().toString());
                  student.setYear(spinnerYear.getSelectedItem().toString());
                  student.setStudNo(etNo.getText().toString());


                  if(student0 != null){
                      student.setId(student0.getId());
                     db.updateStd(student);
                  }
                  else{
                      db.insertStd(student);
                      db.insertUser(student.getStudNo(),"Student");
                  }

                  reset();
                  finish();
              }catch (Exception ex){
                  Toast.makeText(Register.this, ex.getMessage(), Toast.LENGTH_SHORT).show();
              }
            }
        });

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    void setCalender(){
        onCreateDialog(1);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected Dialog onCreateDialog(int id) {
        if(id == 190){
            return new DatePickerDialog(Register.this,dlistener,Calendar.YEAR,Calendar.MONTH,Calendar.DAY_OF_MONTH);
        }
       return null;
    }

    private DatePickerDialog.OnDateSetListener dlistener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            setDate(dayOfMonth,month,year);
        }



    };


    void setDate(int day,int month,int year){
        etDob.setText(new StringBuilder().append(day).append("/").append(month).append("/").append(year));

    }

    void reset(){
        etDob.setText("");
        etName.setText("");
        etCourse.setText("");
        etNo.setText("");
        spinnerNation.setSelection(0);
        spinnerYear.setSelection(0);
        imgStudent.setImageDrawable(getResources().getDrawable(R.drawable.ic_user_24));
    }
}