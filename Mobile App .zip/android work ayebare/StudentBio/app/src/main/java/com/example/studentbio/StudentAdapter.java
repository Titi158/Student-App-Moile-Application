package com.example.studentbio;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.MyViewHolder> {
    Context ctx;
    List<Student> studList;
    public StudentAdapter(Context ctx, List<Student> studList) {
        this.ctx = ctx;
        this.studList = studList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.one_line_student,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
     Student student = (Student) studList.get(position);
     holder.txtYear.setText(student.getYear());
     holder.txtName.setText(student.getName());

        if(student.getImg() != null){
            Bitmap bmp = BitmapFactory.decodeByteArray(student.getImg(),0,student.getImg().length);
            holder.imgStudent.setImageBitmap(bmp);
        }

        holder.layOutLine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             showDialog2(student);
            }
        });

        holder.toolMain2.inflateMenu(R.menu.student_opts);

        holder.toolMain2.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menuItemDelete:
                        showDialog1(student.getStudNo(),student.getId(),position);
                        break;
                    case R.id.menuItemEdit:
                        Intent intent = new Intent(ctx,Register.class);
                        intent.putExtra("Student",student);
                        ctx.startActivity(intent);
                        break;
                }
                return false;
            }
        });
    }

    @Override
    public int getItemCount() {
        return studList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtName,txtYear;
        ImageView imgStudent;
        Toolbar toolMain2;
        RelativeLayout layOutLine;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            txtName = itemView.findViewById(R.id.txtName);
            txtYear = itemView.findViewById(R.id.txtYear);
            imgStudent = itemView.findViewById(R.id.imgStudent);
            toolMain2 = itemView.findViewById(R.id.toolMain2);
            layOutLine = itemView.findViewById(R.id.layOutLine);
        }
    }

    void showDialog1(String num,int num2,int pos){
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
        builder.setCancelable(false);
        builder.setMessage("Delete Student "+num);
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
              DataBase db = new DataBase(ctx);
              db.deleteStudent(num2);
              studList = db.getAll();
              notifyDataSetChanged();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    void showDialog2(Student student){
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
        builder.setCancelable(false);
        LinearLayout layout = new LinearLayout(ctx);
        LayoutInflater.from(ctx).inflate(R.layout.show_student_info,layout,true);

        TextView txtName,txtNo,txtCourse,txtYear,txtNation,txtDob;

        txtName = layout.findViewById(R.id.txtName);
        txtName.setText(student.getName());

        txtNo = layout.findViewById(R.id.txtNo);
        txtNo.setText(student.getStudNo());


        txtCourse = layout.findViewById(R.id.txtCourse);
        txtCourse.setText(student.getCourse());

        txtYear = layout.findViewById(R.id.txtYear);
        txtYear.setText(student.getYear());

        txtNation = layout.findViewById(R.id.txtNation);
        txtNation.setText(student.getNationality());

        txtDob = layout.findViewById(R.id.txtDob);
        txtDob.setText(student.getDob());


        builder.setView(layout);
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });


        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
