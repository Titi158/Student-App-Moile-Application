package com.example.studentbio;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.List;

public class AllStudents extends AppCompatActivity {

    @Override
    protected void onPostResume() {
        super.onPostResume();

        loadData();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_students);

        loadData();

        EditText etSearch = findViewById(R.id.editSearch);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
            loadData2(etSearch.getText().toString());
            }
        });
    }

    void loadData(){
        DataBase db = new DataBase(AllStudents.this);
        List<Student> studList = db.getAll();

        LinearLayout layEmpty = findViewById(R.id.layEmpty);
        RecyclerView recyclerView = findViewById(R.id.lvStudents);

        if(studList.size() > 0){
            layEmpty.setVisibility(View.GONE);
        }
        else{
            recyclerView.setVisibility(View.GONE);
        }
        RecyclerView.Adapter madapter = new StudentAdapter(AllStudents.this,studList);
        recyclerView.setAdapter(madapter);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(AllStudents.this));
    }

    void loadData2(String name){
        DataBase db = new DataBase(AllStudents.this);
        List<Student> studList = db.getAll2(name);


        RecyclerView recyclerView = findViewById(R.id.lvStudents);
        RecyclerView.Adapter madapter = new StudentAdapter(AllStudents.this,studList);
        recyclerView.setAdapter(madapter);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(AllStudents.this));
    }
}